//
//  WorkoutLogView.swift
//  QuestFit
//
//  Created by Max Lopez on 2/22/24.
//

import SwiftUI

struct WorkoutLogView: View {
    var body: some View {
        Text("Workout Log")
    }
}

#Preview {
    WorkoutLogView()
}
