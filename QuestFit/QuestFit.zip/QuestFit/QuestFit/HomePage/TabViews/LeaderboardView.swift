//
//  LeaderboardView.swift
//  QuestFit
//
//  Created by Max Lopez on 2/22/24.
//
import SwiftUI
import FirebaseFirestoreSwift

class LeaderboardViewModel: ObservableObject {
    var authViewModel: AuthViewModel  // Use a regular property instead of @EnvironmentObject
    @Published var leaderboardEntries: [LeaderboardEntry] = []

    init(authViewModel: AuthViewModel) {
        self.authViewModel = authViewModel

        // Fetch the leaderboard upon initialization
        Task {
            do {
                let fetchedLeaderboard = try await authViewModel.fetchLeaderboard()
                self.leaderboardEntries = fetchedLeaderboard
            } catch {
                // Handle error, e.g., show an alert or log the error
                print("Error fetching leaderboard: \(error)")
            }
        }
    }
}

struct LeaderboardView: View {
    @StateObject private var viewModel: LeaderboardViewModel

    init() {
        let authViewModel = AuthViewModel()  // You may need to inject the actual instance from your environment
        _viewModel = StateObject(wrappedValue: LeaderboardViewModel(authViewModel: authViewModel))
    }

    var body: some View {
        let mainColor = Color(red: 0/255, green: 55/255, blue: 0/255)
        let accentColor = Color(red: 152/255, green: 158/255, blue: 143/255)
        
        NavigationView {
            ZStack{
                Color(accentColor)
                List(viewModel.leaderboardEntries) { entry in
                    VStack(alignment: .leading) {
                        Text(entry.username)
                            .font(.headline)
                            .monospaced()
                        Text("Level: \(entry.level)")
                            .font(.subheadline)
                            .monospaced()
                    }
                    .foregroundColor(mainColor)
                    .background(accentColor)
                }
                .navigationTitle("Leaderboard")
            }
        }
    }
}

