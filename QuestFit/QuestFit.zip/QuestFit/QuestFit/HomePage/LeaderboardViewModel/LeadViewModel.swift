//
//  LeadViewModel.swift
//  QuestFit
//
//  Created by Miguel Bunag on 3/8/24.
//

import Firebase
import FirebaseAuth
import FirebaseFirestoreSwift
import Combine

class LeadViewModel {
    
}
